package classic;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Sphere;
import target.BombTarget;
import target.Target;
import java.util.ArrayList;
import java.util.Random;

import Util.TargetUtil;

public class ClassicUtil {
	public static void spawnTargets(ArrayList<Target> targets, Pane pane, int maxTargets, int radius) {
		while (targets.size() <= maxTargets) {
			spawnTarget(targets, pane, radius);
		}
	}

	public static void spawnTarget(ArrayList<Target> targets, Pane pane, int radius) {
		Random random = new Random();
		ArrayList<String> option = new ArrayList<String>();
		for (int i = 0; i <= 40; i++) {
			option.add("BASE");
		}
		option.add("BOMB");
		for (int i = 0; i < 3; i++) {
			option.add("BONUS");
		}
		Target target = null;
		String get = option.get(random.nextInt(option.size()));
		if (get.equals("BASE")) {
			target = new Target(50, Color.AQUA);
		}
		if (get.equals("BOMB")) {
			target = new BombTarget(50, Color.RED);
		}
		if (get.equals("BONUS")) {
			target = new Target(25,Color.GOLD);
		}
		TargetUtil.randomizeValidPosition(targets, target);
		targets.add(target);
		pane.getChildren().add(target);
	}

	public static void mouseClick(double x, double y, ArrayList<Target> targets, Pane pane, int radius) {
		Classic classic = (Classic) pane;
		classic.shotTimes++;

		for (int i = targets.size() - 1; i >= 0; i--) {
			Target target = targets.get(i);
			if (checkClicked(x, y, target, radius)) {
				if (classic.getScore() == 5) {
					targets.clear();
					pane.getChildren().clear();
					classic.gameEnd();
					classic.setScore(0);
					break;
				}
				if (target instanceof BombTarget) {
					((BombTarget) target).perform(targets);
					int listSize = targets.size();
					classic.setScore(classic.getScore() + listSize);
					targets.clear();
					pane.getChildren().clear();
					spawnTargets(targets, pane, listSize, radius);
				} else {
					classic.setScore(classic.getScore() + target.getScore());
					targets.remove(i);
					pane.getChildren().remove(target);
					spawnTarget(targets, pane, radius);
				}
				
				break;
			}
		}
	}

	private static boolean checkClicked(double clickX, double clickY, Sphere target, int radius) {
		return Math.sqrt(
				Math.pow(clickX - target.getTranslateX(), 2) + Math.pow(clickY - target.getTranslateY(), 2)) <= radius;
	}
}
