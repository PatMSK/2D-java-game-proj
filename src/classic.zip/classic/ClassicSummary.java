package classic;

import Util.Config;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import target.GridShot;

public class ClassicSummary extends VBox{
	private int duration;
	private Text durationText;
	private Button restartButton;
	private Button selectMode;
	
	public ClassicSummary(Classic classic) {
		this.setPrefHeight(Config.screenHeight);
		this.setPrefWidth(Config.screenWidth);
   	 	this.createRestartButton();
   	 	this.selectModeButton();
   	 	this.setAlignment(Pos.CENTER);
   	 	this.setSpacing(30);
   	 	this.durationText();
   	 	this.getChildren().addAll(selectMode, restartButton, durationText);
   	 	this.setDuration(classic.getSeconds());
	}
	
	private void selectModeButton() {
		selectMode = new Button("SELECT MODE");
		selectMode.setFont(Font.loadFont("file:font/Valorax-lg25V.otf", 60));
		selectMode.setTextFill(Color.WHITE);
		selectMode.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, null, null)));
		
	}
	
	private void createRestartButton() {
		restartButton = new Button("RESTART");
		restartButton.setFont(Font.loadFont("file:font/Valorax-lg25V.otf", 60));
		restartButton.setTextFill(Color.WHITE);
		restartButton.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, null, null)));
		
	}
	
	private void durationText() {
		durationText = new Text("Duration: "+ this.getDuration() );
		durationText.setFont(Font.loadFont("file:font/Valorax-lg25V.otf", 40));
		durationText.setFill(Color.WHITE);
	}
//	


	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}


	public Button getSelectMode() {
		return selectMode;
	}

	public void setSelectMode(Button selectMode) {
		this.selectMode = selectMode;
	}

	public Button getRestartButton() {
		return restartButton;
	}

	public void setRestartButton(Button restartButton) {
		this.restartButton = restartButton;
	}
	
	
}
