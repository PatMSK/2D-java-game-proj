package classic;

import java.util.ArrayList;

import javafx.scene.Cursor;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import target.Target;
import time.Timer;

public class Classic extends Pane {
	public final int MAX_TARGETS = 6;
	private final int radius = 50;

	private ArrayList<Target> targets;

	private ClassicGui classicPane;
	private Timer countDownPane;
	private ClassicSummary classicSumPane;

	private boolean isStart = false;
	private int score = 0;
	private int seconds = 0;
	public int shotTimes = 0;

	public Classic() {
		Image img = new Image("file:bg/bg.jpg");
		BackgroundImage bImg = new BackgroundImage(img, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
		Background bGround = new Background(bImg);
		this.setBackground(bGround);
		this.initializeGame();
		

		this.setOnMouseClicked(event -> {
			if (isStart) {
				ClassicUtil.mouseClick(event.getX(), event.getY(), targets, this, radius);
			}
		});
	}
	
	private void initializeGame() {
		classicPane = new ClassicGui(this);
		countDownPane = new Timer();
		classicSumPane = new ClassicSummary(this);
		classicSumPane.setVisible(false);
		this.getChildren().addAll(classicPane, countDownPane, classicSumPane);
		targets = new ArrayList<>();
		ClassicUtil.spawnTargets(targets, this, MAX_TARGETS, radius);
		classicPane.toFront();
	}

	public void gameEnd() {
		this.setCursor(Cursor.DEFAULT);
		this.setSeconds(countDownPane.getSeconds());
		this.getChildren().addAll(classicSumPane, classicPane);
		classicSumPane.setVisible(true);
		classicSumPane.toFront();
	}
	
	public void restartGame() {
		this.setSeconds(0);
		this.isStart = true;
		this.getChildren().clear();
		this.initializeGame();
	}


	public void gameStart() {
		this.isStart = true;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getSeconds() {
		return seconds;
	}

	public void setSeconds(int seconds) {
		this.seconds = seconds;
	}

	public ClassicSummary getClassicSumPane() {
		return classicSumPane;
	}

	public void setClassicSumPane(ClassicSummary classicSumPane) {
		this.classicSumPane = classicSumPane;
	}

	public Timer getCountDownPane() {
		return countDownPane;
	}

	public void setCountDownPane(Timer countDownPane) {
		this.countDownPane = countDownPane;
	}
	
	
	
	
}
